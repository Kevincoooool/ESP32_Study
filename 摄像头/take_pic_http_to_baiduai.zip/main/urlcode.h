/*
 * @Descripttion : 
 * @version      : 
 * @Author       : Kevincoooool
 * @Date         : 2021-01-07 14:40:25
 * @LastEditors  : Kevincoooool
 * @LastEditTime : 2021-01-07 18:08:57
 * @FilePath     : \n_esp-adf\1_take_pic_http_to_cloud\main\urlcode.h
 */
/*base64.h*/
#ifndef _URLCODE_H
#define _URLCODE_H

#include <stdlib.h>
#include <string.h>
#include <esp_event_loop.h>
#include <esp_log.h>
#include <esp_system.h>
#include <nvs_flash.h>
#include <sys/param.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app_wifi.h"
#include "esp_camera.h"
#include "esp_http_client.h"

#ifdef __cplusplus
extern "C"
{
#endif

	uint8_t *urlencode(uint8_t *url,uint32_t img_len);

	uint8_t *urldecode(uint8_t *url);
int URLEncode(const char *str, const int strSize, char *result, const int resultSize);
#endif