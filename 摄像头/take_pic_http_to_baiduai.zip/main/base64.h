/*
 * @Descripttion : 
 * @version      : 
 * @Author       : Kevincoooool
 * @Date         : 2021-01-07 14:40:25
 * @LastEditors  : Kevincoooool
 * @LastEditTime : 2021-01-07 14:52:31
 * @FilePath     : \n_esp-adf\1_take_pic_http_to_cloud\main\base64.h
 */
/*base64.h*/  
#ifndef _BASE64_H  
#define _BASE64_H  
  
#include <stdlib.h>  
#include <string.h>  
#include <esp_event_loop.h>
#include <esp_log.h>
#include <esp_system.h>
#include <nvs_flash.h>
#include <sys/param.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app_wifi.h"
#include "esp_camera.h"
#include "esp_http_client.h"

#ifdef __cplusplus
extern "C" {
#endif

uint8_t *base64_encode(uint8_t *str,uint32_t img_len);  
  
uint8_t *bae64_decode(uint8_t *code);  
  
#endif  